## Homework 6

- Due date: Fri 16 Mar 2018 midnight
- Modify hw6.ipynb and follow the instructions there
- Don't forget to add, commit, push the hw
